abstract class ApiConfig {
  static const baseUrl =
      "https://devshamseer.github.io/Kerala-School-DB/kerala-school.json";
}

class ApiEndPoints extends ApiConfig {
  static const schoolList = ApiConfig.baseUrl;
}
