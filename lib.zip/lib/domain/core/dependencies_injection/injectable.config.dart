// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i174;
import 'package:injectable/injectable.dart' as _i526;
import 'package:university_app/application/curent_my_location/curent_my_location_bloc.dart'
    as _i928;
import 'package:university_app/application/school_list/school_list_bloc.dart'
    as _i827;
import 'package:university_app/domain/curent_my_location/get_my_curent_location_service.dart'
    as _i1066;
import 'package:university_app/domain/findSchool/finde_school_services.dart'
    as _i709;
import 'package:university_app/domain/schoolList/schoolList_servises.dart'
    as _i487;
import 'package:university_app/infrastructure/curent_my_location/curent_my_locaton_impl.dart'
    as _i799;
import 'package:university_app/infrastructure/findSchool/findSchool_impl.dart'
    as _i864;
import 'package:university_app/infrastructure/schoolList/schoollist_impl.dart'
    as _i92;

extension GetItInjectableX on _i174.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i174.GetIt init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i526.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    gh.lazySingleton<_i1066.GetCurntMyLoactionService>(
        () => _i799.CurentMyLocatonImpl());
    gh.lazySingleton<_i487.SchoolLIstServise>(() => _i92.ShoolListRepository());
    gh.lazySingleton<_i709.FindSchoolService>(() => _i864.FindSchoolApi());
    gh.factory<_i928.CurentMyLocationBloc>(() =>
        _i928.CurentMyLocationBloc(gh<_i1066.GetCurntMyLoactionService>()));
    gh.factory<_i827.SchoolListBloc>(() => _i827.SchoolListBloc(
          gh<_i487.SchoolLIstServise>(),
          gh<_i709.FindSchoolService>(),
        ));
    return this;
  }
}
