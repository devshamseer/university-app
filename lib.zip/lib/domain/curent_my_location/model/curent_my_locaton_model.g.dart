// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'curent_my_locaton_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CurentMyLocatonModelImpl _$$CurentMyLocatonModelImplFromJson(
        Map<String, dynamic> json) =>
    _$CurentMyLocatonModelImpl(
      myFullLocaton: json['myFullLocaton'] as String?,
      myCurentAdress: json['myCurentAdress'] as String?,
      latitude: json['latitude'] as String?,
      longitude: json['longitude'] as String?,
    );

Map<String, dynamic> _$$CurentMyLocatonModelImplToJson(
        _$CurentMyLocatonModelImpl instance) =>
    <String, dynamic>{
      'myFullLocaton': instance.myFullLocaton,
      'myCurentAdress': instance.myCurentAdress,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
    };
