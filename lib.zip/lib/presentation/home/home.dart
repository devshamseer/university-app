import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:university_app/application/curent_my_location/curent_my_location_bloc.dart';
import 'package:university_app/application/school_list/school_list_bloc.dart';

class Home_Page extends StatelessWidget {
  const Home_Page({super.key});

  @override
  Widget build(BuildContext context) {
    final SearchLoactonTextController = TextEditingController();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      context
          .read<CurentMyLocationBloc>()
          .add(CurentMyLocationEvent.GetCurentLocation());
    });
    return Scaffold(
      body: SafeArea(
          child: BlocConsumer<SchoolListBloc, SchoolListState>(
        listener: (context, state) {
          // TODO: implement listener
        },
        builder: (context, state) {
          return Column(
            children: [
              BlocConsumer<CurentMyLocationBloc, CurentMyLocationState>(
                listener: (context, state) {
                  print('object');
                  log(state.getMyCuretnLocation![0].latitude.toString());
                  context.read<SchoolListBloc>().add(SchoolListEvent.FindSchool(
                      SchoolName: state.getMyCuretnLocation![0].myCurentAdress
                          .toString()));

                  SearchLoactonTextController.text =
                      state.getMyCuretnLocation![0].myCurentAdress.toString();
                },
                builder: (context, state) {
                  // return Text('${state.isLoading.toString()}');

                  if (state.isLoading == true) {
                    return CircularProgressIndicator();
                  } else {
                    return Text(
                        '${state.getMyCuretnLocation![0].myCurentAdress.toString()}');
                  }
                },
              ),

              // ElevatedButton(
              //     onPressed: () {
              //       context
              //           .read<CurentMyLocationBloc>()
              //           .add(CurentMyLocationEvent.GetCurentLocation());
              //     },
              //     child: Text("Location")),
              // ElevatedButton(
              //     onPressed: () {
              //       context
              //           .read<SchoolListBloc>()
              //           .add(SchoolListEvent.GetSchoolList());
              //     },
              //     child: Text('data')),

// BlocBuilder<CurentMyLocationBloc, CurentMyLocationState>(
//   builder: (context, state) {

//    if (state.isLoading==true) {
//       return Text('${state.getMyCuretnLocation![0].myCurentAdress.toString()}');
//    }
//    return SizedBox();
//   },
// ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: SearchLoactonTextController,
                  decoration: InputDecoration(
                    // prefixIcon: Icon(Icons.done),
                    suffix: Text('${state.schoolList!.length}'),

                    hintText: "Search School",
                    filled: true,
                    fillColor: Colors.blueAccent,
                    border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onChanged: (value) {
                    context
                        .read<SchoolListBloc>()
                        .add(SchoolListEvent.FindSchool(SchoolName: value));
                  },
                ),
              ),

              Expanded(
                  child: ListView.builder(
                shrinkWrap: true,
                itemCount: state.schoolList!.length,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 150,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(12)),
                      child: Text('${state.schoolList![index].schoolName}'),
                    ),
                  );
                },
              )),
            ],
          );
        },
      )),
    );
  }
}
